import type { ChatPromptToolId } from "@/components/chat/chat-prompt-box"

/**
 * System-side directives for composer tool chips.
 * Kept out of the visible user bubble — only sent on the system message.
 */
export function buildPromptToolsSystemAppend(tools: ChatPromptToolId[]): string {
  if (tools.length === 0) return ""

  const lines: string[] = [
    "\n\n--- Composer tool modes (user toggled for this turn) ---",
  ]

  if (tools.includes("library")) {
    lines.push(
      "[Library ON] Prefer Arciin library tools for this turn. Search, list, organize, and answer from real folders and libraries on this instance. Do not invent library contents. Call tools when the user asks about their media or folders.",
    )
  }
  if (tools.includes("files")) {
    lines.push(
      "[Files ON] Focus on files and documents already stored on this instance. Use tools to list, search, open, or summarize stored files. Prefer instance file metadata and content over general knowledge.",
    )
  }
  if (tools.includes("vision")) {
    lines.push(
      "[Vision ON] The user enabled vision mode. When image pixels are attached, describe them accurately. If no pixels arrived, say so briefly and suggest a recent image in Images — do not invent visual details.",
    )
  }
  if (tools.includes("thinking")) {
    lines.push(
      "[Think ON] Reason carefully step-by-step before the final answer. Prefer structured intermediate reasoning (thinking traces when the model supports them). Keep the final user-facing answer clear and concise.",
    )
  }

  lines.push("---")
  return lines.join("\n")
}

export function promptToolsForceVision(tools: ChatPromptToolId[]): boolean {
  return tools.includes("vision")
}

export function promptToolsForceThinking(tools: ChatPromptToolId[]): boolean {
  return tools.includes("thinking")
}
